INSERT INTO `advert` (`advertid`, `keyword`, `advert`) VALUES
(1, 'network', 'Bob\'s networks are the best networks in all the world. Buy Bob\'s for the best networks!'),
(2, 'monitoring', 'Network monitoring is difficult. Why not let the ropiest network monitor do it all for you, well at least until it fails and itself catches fire. FreeNATS - network monitoring you definitely can\'t trust.');

